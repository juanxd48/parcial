const MESES = ["ENE", "FEB", "MAR", "ABR", "MAY", "JUN", "JUL", "AGO", "SEP", "OCT", "NOV", "DIC"];

/**
 * Convierte "2026-11-14" en { dia: "14", mes: "NOV" } para mostrarlo
 * como el bloque de fecha de una entrada. Si el formato viene raro,
 * devuelve guiones en vez de romper la vista.
 */
export function formatearFecha(fechaStr) {
  if (!fechaStr) return { dia: "--", mes: "---" };

  const partes = String(fechaStr).split("-").map(Number);
  const [anio, mes, dia] = partes;

  if (!mes || !dia || !MESES[mes - 1]) return { dia: "--", mes: "---" };

  return { dia: String(dia).padStart(2, "0"), mes: MESES[mes - 1] };
}
