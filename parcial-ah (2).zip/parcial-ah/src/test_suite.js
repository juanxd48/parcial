import { connectDB, closeDB } from "./config/db.js";
import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import webRoutes from "./routes/webRoutes.js";
import apiRoutes from "./routes/apiRoutes.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function runTests() {
  const db = await connectDB();
  console.log("Connected to MongoDB for testing.");

  const app = express();
  app.set("view engine", "ejs");
  app.set("views", path.join(__dirname, "..", "views"));
  app.use(express.static(path.join(__dirname, "..", "public")));
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use("/", webRoutes);
  app.use("/api", apiRoutes);

  const server = app.listen(3334);
  const BASE = "http://localhost:3334";

  async function request(p, options = {}) {
    const res = await fetch(`${BASE}${p}`, options);
    let data;
    const contentType = res.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      data = await res.json();
    } else {
      data = await res.text();
    }
    return { status: res.status, data, contentType };
  }

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`  ✅ PASS: ${message}`);
      passed++;
    } else {
      console.error(`  ❌ FAIL: ${message}`);
      failed++;
    }
  }

  try {
    console.log("\n--- TEST 1: Páginas Web Dinámicas (Parte 1) ---");
    const home = await request("/");
    assert(home.status === 200, "GET / devuelve 200");
    assert(home.data.includes("EN CARTEL"), "GET / contiene título");
    assert(home.data.includes("Rock") && home.data.includes("Metal"), "GET / contiene las 5 secciones");

    const rock = await request("/seccion/rock");
    assert(rock.status === 200, "GET /seccion/rock devuelve 200");
    assert(rock.data.includes("Rock"), "GET /seccion/rock muestra título del género");

    const admin = await request("/admin");
    assert(admin.status === 200, "GET /admin devuelve 200");

    const clientesWeb = await request("/clientes");
    assert(clientesWeb.status === 200, "GET /clientes devuelve 200");

    console.log("\n--- TEST 2: API REST - Recitales (Parte 2) ---");
    const listRecitales = await request("/api/recitales");
    assert(listRecitales.status === 200 && Array.isArray(listRecitales.data), "GET /api/recitales devuelve array");
    assert(listRecitales.data.length > 0, "GET /api/recitales tiene elementos");

    // Filtrar por 2 campos (sección y artista)
    const filter2 = await request("/api/recitales?seccion=rock&artista=Airbag");
    assert(filter2.status === 200 && Array.isArray(filter2.data), "GET /api/recitales filtrado por 2 campos (seccion y artista) funciona");

    // Crear recital (POST)
    const nuevoRecital = {
      nombre: "Recital Test Automatizado",
      descripcion: "Descripción de prueba para verificar cumplimiento",
      link: "https://ejemplo.com/entradas-test",
      imagen: "https://picsum.photos/400/225",
      fecha: "2026-11-30",
      lugar: "Estadio Obras",
      artistas: ["Banda Test 1", "Banda Test 2"],
      seccion: "rock",
    };
    const postRes = await request("/api/recitales", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(nuevoRecital),
    });
    assert(postRes.status === 201 && postRes.data._id, "POST /api/recitales crea un recital con 201");
    const createdId = postRes.data._id;

    // Obtener por ID (GET /:id)
    const getById = await request(`/api/recitales/${createdId}`);
    assert(getById.status === 200 && getById.data.nombre === nuevoRecital.nombre, "GET /api/recitales/:id trae el recital creado");

    // Modificar recital (PUT /:id)
    const putRes = await request(`/api/recitales/${createdId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nombre: "Recital Test Modificado" }),
    });
    assert(putRes.status === 200 && putRes.data.nombre === "Recital Test Modificado", "PUT /api/recitales/:id modifica el recital con 200");

    // Eliminar recital (DELETE /:id)
    const delRes = await request(`/api/recitales/${createdId}`, { method: "DELETE" });
    assert(delRes.status === 200 || delRes.status === 204, "DELETE /api/recitales/:id elimina el recital");

    // Verificar que ya no existe (404)
    const getDeleted = await request(`/api/recitales/${createdId}`);
    assert(getDeleted.status === 404, "GET /api/recitales/:id borrado devuelve 404");

    console.log("\n--- TEST 3: Clientes y Proyectos (Parte 3) ---");
    // Listar clientes
    const listClientes = await request("/api/clientes");
    assert(listClientes.status === 200 && Array.isArray(listClientes.data), "GET /api/clientes devuelve lista");
    assert(listClientes.data.length >= 2, "Hay al menos 2 clientes cargados");

    // Crear cliente (POST)
    const nuevoCliente = {
      nombre: "Productora Test Automatizada",
      foto: "https://picsum.photos/200",
      descripcion: "Cliente creado para test de consigna",
    };
    const postCliente = await request("/api/clientes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(nuevoCliente),
    });
    assert(postCliente.status === 201 && postCliente.data._id, "POST /api/clientes crea cliente con 201");
    const nuevoClienteId = postCliente.data._id;

    // Obtener proyectos del cliente recién creado (debe tener 0 proyectos -> [])
    const proyectosClienteNuevo = await request(`/api/clientes/${nuevoClienteId}/proyectos`);
    assert(
      proyectosClienteNuevo.status === 200 &&
      Array.isArray(proyectosClienteNuevo.data) &&
      proyectosClienteNuevo.data.length === 0,
      "GET /api/clientes/:id/proyectos de cliente sin proyectos devuelve array vacío []"
    );

    // Crear proyecto para este cliente en particular
    const postProyecto = await request("/api/proyectos", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        nombre: "Festival de Productora Test",
        descripcion: "Proyecto musical asignado",
        clienteId: nuevoClienteId,
      }),
    });
    assert(postProyecto.status === 201 && postProyecto.data._id, "POST /api/proyectos crea proyecto con clienteId");

    // Verificar que ahora tiene 1 proyecto
    const proyectosClienteDespues = await request(`/api/clientes/${nuevoClienteId}/proyectos`);
    assert(
      proyectosClienteDespues.status === 200 &&
      proyectosClienteDespues.data.length === 1,
      "GET /api/clientes/:id/proyectos ahora devuelve el proyecto creado para él"
    );

    // Cliente inexistente debe devolver 404
    const clienteInexistente = await request("/api/clientes/60c72b2f9b1d8b0015f8a000/proyectos");
    assert(clienteInexistente.status === 404, "GET /api/clientes/inexistente/proyectos devuelve 404");

    // Limpiar cliente y proyecto de prueba
    await request(`/api/clientes/${nuevoClienteId}`, { method: "DELETE" });

    console.log(`\n================================`);
    console.log(`RESULTADOS: ${passed} pasados, ${failed} fallados`);
    console.log(`================================\n`);
  } finally {
    server.close();
    await closeDB();
  }

  if (failed > 0) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

runTests().catch((err) => {
  console.error("Error en pruebas:", err);
  process.exit(1);
});
