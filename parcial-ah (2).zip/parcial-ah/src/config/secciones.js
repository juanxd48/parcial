// Secciones = géneros musicales. Cada uno tiene su propio color, como si
// fuera un cartel serigrafiado distinto por género.
export const SECCIONES = [
  { nombre: "Rock", slug: "rock", color: "#FF3B3F" },
  { nombre: "Pop", slug: "pop", color: "#FF5FA8" },
  { nombre: "Electrónica", slug: "electronica", color: "#29E7CD" },
  { nombre: "Indie", slug: "indie", color: "#FFC145" },
  { nombre: "Metal", slug: "metal", color: "#B24BF3" },
];

export function existeSeccion(slug) {
  return SECCIONES.some((s) => s.slug === slug);
}
