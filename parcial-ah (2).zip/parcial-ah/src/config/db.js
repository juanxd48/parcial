import { MongoClient } from "mongodb";
import "dotenv/config";

const uri = process.env.MONGO_URI || "mongodb://127.0.0.1:27017";
const dbName = process.env.DB_NAME || "AH20232CP1";

let client;
let db;

/**
 * Conecta una única vez a MongoDB y guarda la instancia de la base
 * para reutilizarla en toda la app (patrón singleton).
 */
export async function connectDB() {
  if (db) return db;

  client = new MongoClient(uri);
  await client.connect();
  db = client.db(dbName);

  console.log(`✅ Conectado a MongoDB -> base: ${dbName}`);
  return db;
}

/**
 * Devuelve la instancia de la base ya conectada.
 * Tira error si todavía no se llamó a connectDB().
 */
export function getDB() {
  if (!db) {
    throw new Error("La base de datos no está conectada. Llamá a connectDB() primero.");
  }
  return db;
}

export async function closeDB() {
  if (client) await client.close();
}
