import { Router } from "express";
import {
  listarRecitales,
  obtenerRecital,
  crear,
  actualizar,
  eliminar,
  listarBandas,
  obtenerBandaHandler,
  crearBandaHandler,
  recitalesDeBanda,
  listarClientes,
  obtenerClienteHandler,
  crearClienteHandler,
  actualizarClienteHandler,
  eliminarClienteHandler,
  listarProyectosDeCliente,
  crearProyectoHandler,
} from "../controllers/apiController.js";

const router = Router();

// ========================================================
// Recitales (Parte 2: 4 operaciones básicas + filtrado x 2 campos)
// ========================================================
router.get("/recitales", listarRecitales);
router.get("/recitales/:id", obtenerRecital);
router.post("/recitales", crear);
router.put("/recitales/:id", actualizar);
router.patch("/recitales/:id", actualizar);
router.delete("/recitales/:id", eliminar);

// Alias /proyectos para garantizar 100% compatibilidad con tests literales
router.get("/proyectos", listarRecitales);
router.get("/proyectos/:id", obtenerRecital);
router.post("/proyectos", crearProyectoHandler);
router.put("/proyectos/:id", actualizar);
router.patch("/proyectos/:id", actualizar);
router.delete("/proyectos/:id", eliminar);

// ========================================================
// Clientes (Parte 3: Entidad Cliente y relación con proyectos)
// ========================================================
router.get("/clientes", listarClientes);
router.get("/clientes/:id", obtenerClienteHandler);
router.post("/clientes", crearClienteHandler);
router.put("/clientes/:id", actualizarClienteHandler);
router.delete("/clientes/:id", eliminarClienteHandler);

// Proyectos / Recitales de un cliente particular
router.get("/clientes/:id/proyectos", listarProyectosDeCliente);
router.get("/clientes/:id/recitales", listarProyectosDeCliente);

// ========================================================
// Bandas (Entidad temática complementaria)
// ========================================================
router.get("/bandas", listarBandas);
router.get("/bandas/:id", obtenerBandaHandler);
router.post("/bandas", crearBandaHandler);
router.get("/bandas/:id/recitales", recitalesDeBanda);

export default router;
