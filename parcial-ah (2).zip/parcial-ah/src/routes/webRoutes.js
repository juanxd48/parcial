import { Router } from "express";
import {
  mostrarMenu,
  mostrarSeccion,
  mostrarAdmin,
  mostrarFormularioRecital,
  crearRecitalWeb,
  actualizarRecitalWeb,
  eliminarRecitalWeb,
  mostrarFormularioBanda,
  crearBandaWeb,
  eliminarBandaWeb,
  mostrarClientes,
  mostrarCuentaCliente,
  mostrarFormularioCliente,
  crearClienteWeb,
  eliminarClienteWeb,
} from "../controllers/webController.js";

const router = Router();

// Navegación principal
router.get("/", mostrarMenu);
router.get("/seccion/:slug", mostrarSeccion);

// Panel de administración (ABM)
router.get("/admin", mostrarAdmin);

// ABM de recitales
router.get("/recitales/nuevo", mostrarFormularioRecital);
router.post("/recitales", crearRecitalWeb);
router.get("/recitales/:id/editar", mostrarFormularioRecital);
router.post("/recitales/:id/editar", actualizarRecitalWeb);
router.post("/recitales/:id/eliminar", eliminarRecitalWeb);

// ABM y vistas de clientes / cuentas (Parte 3)
router.get("/clientes", mostrarClientes);
router.get("/clientes/nuevo", mostrarFormularioCliente);
router.post("/clientes", crearClienteWeb);
router.get("/clientes/:id", mostrarCuentaCliente);
router.post("/clientes/:id/eliminar", eliminarClienteWeb);

// ABM de bandas
router.get("/bandas/nuevo", mostrarFormularioBanda);
router.post("/bandas", crearBandaWeb);
router.post("/bandas/:id/eliminar", eliminarBandaWeb);

export default router;
