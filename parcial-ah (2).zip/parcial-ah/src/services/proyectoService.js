import { ObjectId } from "mongodb";
import { getDB } from "../config/db.js";
import { obtenerRecitalesPorCliente, crearRecital } from "./recitalService.js";

const COLLECTION = "proyectos";

function coleccion() {
  return getDB().collection(COLLECTION);
}

/**
 * Obtiene todos los proyectos pertenecientes a un cliente particular.
 * Incluye tanto los recitales producidos para ese cliente como cualquier
 * documento en la colección de proyectos.
 */
export async function obtenerProyectosPorCliente(clienteId) {
  if (!ObjectId.isValid(clienteId)) return [];

  const recitalesDelCliente = await obtenerRecitalesPorCliente(clienteId);
  const proyectosLegacy = await coleccion().find({ clienteId: new ObjectId(clienteId) }).toArray();

  // Mapeamos los recitales al formato de proyecto si fuera necesario
  const proyectosRecitales = recitalesDelCliente.map((r) => ({
    _id: r._id,
    nombre: r.nombre,
    descripcion: r.descripcion,
    link: r.link,
    imagen: r.imagen,
    seccion: r.seccion,
    artistas: r.artistas,
    fecha: r.fecha,
    lugar: r.lugar,
    clienteId: r.clienteId,
    tipo: "recital",
  }));

  // Retornamos ambos sin duplicados por ID
  const idsVistos = new Set(proyectosRecitales.map((p) => String(p._id)));
  const todos = [...proyectosRecitales];

  for (const pl of proyectosLegacy) {
    if (!idsVistos.has(String(pl._id))) {
      todos.push(pl);
      idsVistos.add(String(pl._id));
    }
  }

  return todos;
}

/**
 * Crea un proyecto asociado a un cliente. Guarda en recitales para
 * que se refleje inmediatamente en el sistema web de recitales y
 * además permite compatibilidad total.
 */
export async function crearProyecto(data) {
  const clienteId = data.clienteId || data.clientId;
  if (!clienteId || !ObjectId.isValid(clienteId)) {
    throw new Error("clienteId no es válido o falta");
  }

  // Guardamos como recital/proyecto para que sea visible en todas las vistas
  const nuevo = await crearRecital({
    nombre: data.nombre || data.name,
    descripcion: data.descripcion || data.description,
    link: data.link || "https://ejemplo.com",
    imagen: data.imagen || data.img || data.foto || "https://picsum.photos/400/225",
    seccion: data.seccion || data.section || "rock",
    artistas: data.artistas || data.technologies || [],
    fecha: data.fecha || new Date().toISOString().split("T")[0],
    lugar: data.lugar || "Buenos Aires",
    clienteId: new ObjectId(clienteId),
  });

  // Guardamos también en colección proyectos para consistencia histórica
  await coleccion().insertOne({
    _id: nuevo._id,
    nombre: nuevo.nombre,
    descripcion: nuevo.descripcion,
    clienteId: new ObjectId(clienteId),
    creadoEn: new Date(),
  });

  return nuevo;
}

export async function obtenerTodosLosProyectos() {
  const delServicio = await getDB().collection("recitales").find({}).toArray();
  return delServicio;
}
