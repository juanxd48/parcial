import { ObjectId } from "mongodb";
import { getDB } from "../config/db.js";

const COLLECTION = "bandas";

function coleccion() {
  return getDB().collection(COLLECTION);
}

function normalizarBanda(data) {
  const doc = {};
  const nombre = data.nombre !== undefined ? data.nombre : data.name;
  if (nombre !== undefined) doc.nombre = String(nombre).trim();

  const foto = data.foto !== undefined ? data.foto : (data.photo !== undefined ? data.photo : data.img);
  if (foto !== undefined) doc.foto = String(foto).trim();

  const descripcion = data.descripcion !== undefined ? data.descripcion : data.description;
  if (descripcion !== undefined) doc.descripcion = String(descripcion).trim();

  return doc;
}

export async function obtenerBandas() {
  return coleccion().find({}).sort({ nombre: 1 }).toArray();
}

export async function obtenerBandaPorId(id) {
  if (!ObjectId.isValid(id)) return null;
  return coleccion().findOne({ _id: new ObjectId(id) });
}

export async function crearBanda(data) {
  const norm = normalizarBanda(data);
  const nuevaBanda = {
    nombre: norm.nombre || "Banda sin nombre",
    foto: norm.foto || "https://picsum.photos/200",
    descripcion: norm.descripcion || "",
    creadoEn: new Date(),
  };

  const resultado = await coleccion().insertOne(nuevaBanda);
  return { _id: resultado.insertedId, ...nuevaBanda };
}

export async function actualizarBanda(id, data) {
  if (!ObjectId.isValid(id)) return null;
  const norm = normalizarBanda(data);
  norm.actualizadoEn = new Date();

  await coleccion().updateOne({ _id: new ObjectId(id) }, { $set: norm });
  return obtenerBandaPorId(id);
}

export async function eliminarBanda(id) {
  if (!ObjectId.isValid(id)) return false;
  const resultado = await coleccion().deleteOne({ _id: new ObjectId(id) });
  return resultado.deletedCount === 1;
}
