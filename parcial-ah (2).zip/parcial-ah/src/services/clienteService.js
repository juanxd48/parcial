import { ObjectId } from "mongodb";
import { getDB } from "../config/db.js";

const COLLECTION = "clientes";

function coleccion() {
  return getDB().collection(COLLECTION);
}

function normalizarCliente(data) {
  const doc = {};
  const nombre = data.nombre !== undefined ? data.nombre : data.name;
  if (nombre !== undefined) doc.nombre = String(nombre).trim();

  const foto = data.foto !== undefined ? data.foto : (data.photo !== undefined ? data.photo : data.img);
  if (foto !== undefined) doc.foto = String(foto).trim();

  const descripcion = data.descripcion !== undefined ? data.descripcion : data.description;
  if (descripcion !== undefined) doc.descripcion = String(descripcion).trim();

  return doc;
}

export async function obtenerClientes() {
  return coleccion().find({}).sort({ nombre: 1 }).toArray();
}

export async function obtenerClientePorId(id) {
  if (!ObjectId.isValid(id)) return null;
  return coleccion().findOne({ _id: new ObjectId(id) });
}

export async function crearCliente(data) {
  const norm = normalizarCliente(data);
  const nuevoCliente = {
    nombre: norm.nombre || "Cliente sin nombre",
    foto: norm.foto || "https://picsum.photos/200",
    descripcion: norm.descripcion || "",
    creadoEn: new Date(),
  };

  const resultado = await coleccion().insertOne(nuevoCliente);
  return { _id: resultado.insertedId, ...nuevoCliente };
}

export async function actualizarCliente(id, data) {
  if (!ObjectId.isValid(id)) return null;
  const cambios = normalizarCliente(data);
  cambios.actualizadoEn = new Date();

  await coleccion().updateOne({ _id: new ObjectId(id) }, { $set: cambios });
  return obtenerClientePorId(id);
}

export async function eliminarCliente(id) {
  if (!ObjectId.isValid(id)) return false;
  const resultado = await coleccion().deleteOne({ _id: new ObjectId(id) });
  return resultado.deletedCount === 1;
}
