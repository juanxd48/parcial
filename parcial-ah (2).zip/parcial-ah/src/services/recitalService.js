import { ObjectId } from "mongodb";
import { getDB } from "../config/db.js";

const COLLECTION = "recitales";

function coleccion() {
  return getDB().collection(COLLECTION);
}

/**
 * Normaliza los datos de entrada para admitir tanto nombres de campos en
 * español como en inglés (cumpliendo al 100% con los ejemplos de la consigna).
 */
function normalizarDatos(data) {
  const artistasArray = data.artistas !== undefined ? data.artistas : data.technologies;
  const artistas = Array.isArray(artistasArray)
    ? artistasArray
    : String(artistasArray || "")
        .split(",")
        .map((a) => a.trim())
        .filter(Boolean);

  const doc = {};

  const nombre = data.nombre !== undefined ? data.nombre : data.name;
  if (nombre !== undefined) doc.nombre = String(nombre).trim();

  const descripcion = data.descripcion !== undefined ? data.descripcion : data.description;
  if (descripcion !== undefined) doc.descripcion = String(descripcion).trim();

  const link = data.link !== undefined ? data.link : data.url;
  if (link !== undefined) doc.link = String(link).trim();

  const imagen = data.imagen !== undefined ? data.imagen : (data.img !== undefined ? data.img : data.foto);
  if (imagen !== undefined) doc.imagen = String(imagen).trim();

  const seccion = data.seccion !== undefined ? data.seccion : data.section;
  if (seccion !== undefined) doc.seccion = String(seccion).trim().toLowerCase();

  if (data.fecha !== undefined) doc.fecha = String(data.fecha).trim();
  if (data.lugar !== undefined) doc.lugar = String(data.lugar).trim();

  if (artistasArray !== undefined) {
    doc.artistas = artistas;
  }

  const clienteId = data.clienteId !== undefined ? data.clienteId : data.clientId;
  if (clienteId !== undefined) {
    doc.clienteId = clienteId && ObjectId.isValid(clienteId) ? new ObjectId(clienteId) : null;
  }

  const bandaId = data.bandaId !== undefined ? data.bandaId : data.bandId;
  if (bandaId !== undefined) {
    doc.bandaId = bandaId && ObjectId.isValid(bandaId) ? new ObjectId(bandaId) : null;
  }

  return doc;
}

/**
 * Trae todos los recitales / proyectos. Permite filtrar por al menos dos campos
 * (ej: seccion y artista, o seccion y clienteId, lugar, etc.).
 */
export async function obtenerRecitales(filtros = {}) {
  const query = {};

  const seccion = filtros.seccion || filtros.section;
  if (seccion) {
    query.seccion = String(seccion).toLowerCase();
  }

  const artista = filtros.artista || filtros.technologies || filtros.tecnologia;
  if (artista) {
    query.artistas = { $regex: new RegExp(String(artista).trim(), "i") };
  }

  const clienteId = filtros.clienteId || filtros.clientId;
  if (clienteId && ObjectId.isValid(clienteId)) {
    query.clienteId = new ObjectId(clienteId);
  }

  const bandaId = filtros.bandaId || filtros.bandId;
  if (bandaId && ObjectId.isValid(bandaId)) {
    query.bandaId = new ObjectId(bandaId);
  }

  const lugar = filtros.lugar;
  if (lugar) {
    query.lugar = { $regex: new RegExp(String(lugar).trim(), "i") };
  }

  if (filtros.q) {
    const regex = { $regex: new RegExp(String(filtros.q).trim(), "i") };
    query.$or = [{ nombre: regex }, { descripcion: regex }, { lugar: regex }, { artistas: regex }];
  }

  return coleccion().find(query).sort({ fecha: 1 }).toArray();
}

export async function obtenerRecitalPorId(id) {
  if (!ObjectId.isValid(id)) return null;
  return coleccion().findOne({ _id: new ObjectId(id) });
}

/**
 * Trae todos los recitales / proyectos producidos para un cliente particular (Parte 3).
 */
export async function obtenerRecitalesPorCliente(clienteId) {
  if (!ObjectId.isValid(clienteId)) return [];
  return coleccion().find({ clienteId: new ObjectId(clienteId) }).sort({ fecha: 1 }).toArray();
}

export async function obtenerRecitalesPorBanda(bandaId) {
  if (!ObjectId.isValid(bandaId)) return [];
  return coleccion().find({ bandaId: new ObjectId(bandaId) }).sort({ fecha: 1 }).toArray();
}

/**
 * Crea un nuevo recital / proyecto en la base de datos.
 */
export async function crearRecital(data) {
  const doc = normalizarDatos(data);

  // Asegurar campos predeterminados
  const nuevoRecital = {
    nombre: doc.nombre || "Recital sin título",
    descripcion: doc.descripcion || "",
    link: doc.link || "https://ejemplo.com",
    imagen: doc.imagen || "https://picsum.photos/400/225",
    fecha: doc.fecha || new Date().toISOString().split("T")[0],
    lugar: doc.lugar || "Buenos Aires",
    artistas: doc.artistas || [],
    seccion: doc.seccion || "rock",
    clienteId: doc.clienteId || null,
    bandaId: doc.bandaId || null,
    creadoEn: new Date(),
  };

  const resultado = await coleccion().insertOne(nuevoRecital);
  return { _id: resultado.insertedId, ...nuevoRecital };
}

/**
 * Actualiza un recital existente por su ID.
 */
export async function actualizarRecital(id, data) {
  if (!ObjectId.isValid(id)) return null;

  const cambios = normalizarDatos(data);
  cambios.actualizadoEn = new Date();

  await coleccion().updateOne({ _id: new ObjectId(id) }, { $set: cambios });
  return obtenerRecitalPorId(id);
}

/**
 * Elimina un recital por su ID.
 */
export async function eliminarRecital(id) {
  if (!ObjectId.isValid(id)) return false;
  const resultado = await coleccion().deleteOne({ _id: new ObjectId(id) });
  return resultado.deletedCount === 1;
}

/**
 * Cuenta la cantidad de recitales por género/sección.
 */
export async function contarPorSeccion() {
  const conteo = await coleccion()
    .aggregate([{ $group: { _id: "$seccion", total: { $sum: 1 } } }])
    .toArray();

  const mapa = {};
  for (const item of conteo) {
    if (item._id) mapa[item._id] = item.total;
  }
  return mapa;
}
