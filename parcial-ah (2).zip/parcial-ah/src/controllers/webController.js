import { SECCIONES, existeSeccion } from "../config/secciones.js";
import {
  obtenerRecitales,
  obtenerRecitalPorId,
  crearRecital,
  actualizarRecital,
  eliminarRecital,
  contarPorSeccion,
} from "../services/recitalService.js";
import {
  obtenerBandas,
  crearBanda,
  eliminarBanda,
} from "../services/bandaService.js";
import {
  obtenerClientes,
  obtenerClientePorId,
  crearCliente,
  eliminarCliente,
} from "../services/clienteService.js";
import { obtenerProyectosPorCliente } from "../services/proyectoService.js";
import { formatearFecha } from "../utils/fecha.js";

export async function mostrarMenu(req, res) {
  try {
    const conteo = await contarPorSeccion();
    const [recitales, clientes, bandas] = await Promise.all([
      obtenerRecitales({}),
      obtenerClientes(),
      obtenerBandas(),
    ]);

    const seccionesConConteo = SECCIONES.map((s) => ({
      ...s,
      total: conteo[s.slug] || 0,
    }));

    const destacados = recitales.slice(0, 4).map((r) => ({
      ...r,
      fechaFormateada: formatearFecha(r.fecha),
    }));

    const stats = {
      totalRecitales: recitales.length,
      totalClientes: clientes.length,
      totalBandas: bandas.length,
      totalGeneros: SECCIONES.length,
    };

    res.render("index", {
      secciones: seccionesConConteo,
      stats,
      destacados,
    });
  } catch (error) {
    res.status(500).send("Error al cargar la página de inicio: " + error.message);
  }
}

export async function mostrarSeccion(req, res) {
  try {
    const { slug } = req.params;

    if (!existeSeccion(slug)) {
      return res.status(404).render("404", { slug });
    }

    const [recitales, clientes, bandas] = await Promise.all([
      obtenerRecitales({ seccion: slug }),
      obtenerClientes(),
      obtenerBandas(),
    ]);

    const seccionActual = SECCIONES.find((s) => s.slug === slug);
    const clientesMap = new Map(clientes.map((c) => [String(c._id), c]));
    const bandasMap = new Map(bandas.map((b) => [String(b._id), b]));

    const recitalesEnriquecidos = recitales.map((r) => {
      const cliente = r.clienteId ? clientesMap.get(String(r.clienteId)) : null;
      const banda = r.bandaId ? bandasMap.get(String(r.bandaId)) : null;

      return {
        ...r,
        fechaFormateada: formatearFecha(r.fecha),
        clienteNombre: cliente ? cliente.nombre : null,
        clienteFoto: cliente ? cliente.foto : null,
        bandaNombre: banda ? banda.nombre : null,
      };
    });

    res.render("seccion", {
      seccion: seccionActual,
      secciones: SECCIONES,
      recitales: recitalesEnriquecidos,
    });
  } catch (error) {
    res.status(500).send("Error al cargar la sección: " + error.message);
  }
}

// ---------- ABM: panel de administración ----------

export async function mostrarAdmin(req, res) {
  try {
    const [recitales, bandas, clientes] = await Promise.all([
      obtenerRecitales({}),
      obtenerBandas(),
      obtenerClientes(),
    ]);

    const bandasPorId = new Map(bandas.map((b) => [String(b._id), b.nombre]));
    const clientesPorId = new Map(clientes.map((c) => [String(c._id), c.nombre]));

    // Calcular cuántos recitales tiene cada cliente
    const conteoRecitalesPorCliente = new Map();
    for (const r of recitales) {
      if (r.clienteId) {
        const idStr = String(r.clienteId);
        conteoRecitalesPorCliente.set(idStr, (conteoRecitalesPorCliente.get(idStr) || 0) + 1);
      }
    }

    const clientesConConteo = clientes.map((c) => ({
      ...c,
      totalProyectos: conteoRecitalesPorCliente.get(String(c._id)) || 0,
    }));

    const recitalesConRelaciones = recitales.map((r) => ({
      ...r,
      bandaNombre: r.bandaId ? bandasPorId.get(String(r.bandaId)) || "—" : "—",
      clienteNombre: r.clienteId ? clientesPorId.get(String(r.clienteId)) || "—" : "—",
      fechaFormateada: formatearFecha(r.fecha),
    }));

    const stats = {
      totalRecitales: recitales.length,
      totalBandas: bandas.length,
      totalClientes: clientes.length,
      totalGeneros: SECCIONES.length,
    };

    res.render("admin", {
      recitales: recitalesConRelaciones,
      bandas,
      clientes: clientesConConteo,
      stats,
    });
  } catch (error) {
    res.status(500).send("Error al cargar el panel de administración: " + error.message);
  }
}

// ---------- ABM: recitales ----------

export async function mostrarFormularioRecital(req, res) {
  try {
    const { id } = req.params;
    let recital = null;

    if (id) {
      recital = await obtenerRecitalPorId(id);
      if (!recital) return res.status(404).send("Recital no encontrado");
    }

    const [bandas, clientes] = await Promise.all([obtenerBandas(), obtenerClientes()]);

    res.render("recital-form", {
      recital,
      bandas,
      clientes,
      secciones: SECCIONES,
      clienteIdPreseleccionado: req.query.clienteId || null,
    });
  } catch (error) {
    res.status(500).send("Error al abrir formulario de recital: " + error.message);
  }
}

export async function crearRecitalWeb(req, res) {
  try {
    await crearRecital(req.body);
    res.redirect("/admin");
  } catch (error) {
    res.status(500).send("Error al crear recital: " + error.message);
  }
}

export async function actualizarRecitalWeb(req, res) {
  try {
    await actualizarRecital(req.params.id, req.body);
    res.redirect("/admin");
  } catch (error) {
    res.status(500).send("Error al actualizar recital: " + error.message);
  }
}

export async function eliminarRecitalWeb(req, res) {
  try {
    await eliminarRecital(req.params.id);
    res.redirect("/admin");
  } catch (error) {
    res.status(500).send("Error al eliminar recital: " + error.message);
  }
}

// ---------- ABM: bandas ----------

export function mostrarFormularioBanda(req, res) {
  res.render("banda-form");
}

export async function crearBandaWeb(req, res) {
  try {
    await crearBanda(req.body);
    res.redirect("/admin");
  } catch (error) {
    res.status(500).send("Error al crear banda: " + error.message);
  }
}

export async function eliminarBandaWeb(req, res) {
  try {
    await eliminarBanda(req.params.id);
    res.redirect("/admin");
  } catch (error) {
    res.status(500).send("Error al eliminar banda: " + error.message);
  }
}

// ---------- Clientes: sección de cuentas ----------

export function mostrarFormularioCliente(req, res) {
  res.render("cliente-form");
}

export async function crearClienteWeb(req, res) {
  try {
    const { nombre, foto, descripcion } = req.body;

    if (!nombre || !foto || !descripcion) {
      return res.status(400).send("Todos los campos son obligatorios: nombre, foto y descripción.");
    }

    await crearCliente({ nombre, foto, descripcion });
    res.redirect("/clientes");
  } catch (error) {
    res.status(500).send("Error al crear cliente: " + error.message);
  }
}

export async function eliminarClienteWeb(req, res) {
  try {
    await eliminarCliente(req.params.id);
    res.redirect("/admin");
  } catch (error) {
    res.status(500).send("Error al eliminar cliente: " + error.message);
  }
}

export async function mostrarClientes(req, res) {
  try {
    const [clientes, recitales] = await Promise.all([
      obtenerClientes(),
      obtenerRecitales({}),
    ]);

    const conteoRecitalesPorCliente = new Map();
    for (const r of recitales) {
      if (r.clienteId) {
        const idStr = String(r.clienteId);
        conteoRecitalesPorCliente.set(idStr, (conteoRecitalesPorCliente.get(idStr) || 0) + 1);
      }
    }

    const clientesConConteo = clientes.map((c) => ({
      ...c,
      totalProyectos: conteoRecitalesPorCliente.get(String(c._id)) || 0,
    }));

    res.render("clientes", { clientes: clientesConConteo });
  } catch (error) {
    res.status(500).send("Error al listar clientes: " + error.message);
  }
}

export async function mostrarCuentaCliente(req, res) {
  try {
    const { id } = req.params;
    const cliente = await obtenerClientePorId(id);

    if (!cliente) {
      return res.status(404).render("404", { slug: "cliente" });
    }

    const proyectos = await obtenerProyectosPorCliente(id);

    const proyectosConFecha = proyectos.map((p) => ({
      ...p,
      fechaFormateada: formatearFecha(p.fecha),
    }));

    res.render("cliente", { cliente, proyectos: proyectosConFecha });
  } catch (error) {
    res.status(500).send("Error al ver cuenta de cliente: " + error.message);
  }
}
