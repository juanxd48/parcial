import { existeSeccion } from "../config/secciones.js";
import { ObjectId } from "mongodb";
import {
  obtenerRecitales,
  obtenerRecitalPorId,
  obtenerRecitalesPorBanda,
  obtenerRecitalesPorCliente,
  crearRecital,
  actualizarRecital,
  eliminarRecital,
} from "../services/recitalService.js";
import {
  obtenerBandas,
  obtenerBandaPorId,
  crearBanda,
} from "../services/bandaService.js";
import {
  obtenerClientes,
  obtenerClientePorId,
  crearCliente,
  actualizarCliente,
  eliminarCliente,
} from "../services/clienteService.js";
import {
  obtenerProyectosPorCliente,
  crearProyecto,
} from "../services/proyectoService.js";

// Helper para validar campos obligatorios aceptando alias en español e inglés
function validarCamposObligatorios(body, gruposCampos) {
  const faltantes = [];
  for (const grupo of gruposCampos) {
    const presente = grupo.some((campo) => body[campo] !== undefined && String(body[campo]).trim() !== "");
    if (!presente) {
      faltantes.push(grupo[0]);
    }
  }
  return faltantes;
}

// ==========================================
// RECITALES / PROYECTOS (Parte 1 y 2)
// ==========================================

/**
 * GET /api/recitales  o  GET /api/proyectos
 * Trae todos los recitales/proyectos. Permite filtrar por dos campos (o más):
 * ej: ?seccion=rock&artista=Airbag
 * ej: ?seccion=indie&clienteId=65f...
 */
export async function listarRecitales(req, res) {
  try {
    const { seccion, section, artista, technologies, tecnologia, clienteId, clientId, bandaId, lugar, q } = req.query;

    const recitales = await obtenerRecitales({
      seccion: seccion || section,
      artista: artista || technologies || tecnologia,
      clienteId: clienteId || clientId,
      bandaId,
      lugar,
      q,
    });

    res.json(recitales);
  } catch (error) {
    res.status(500).json({ error: "Error al obtener los recitales", detalle: error.message });
  }
}

/**
 * GET /api/recitales/:id  o  GET /api/proyectos/:id
 */
export async function obtenerRecital(req, res) {
  try {
    const { id } = req.params;
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: "El ID proporcionado no es válido" });
    }

    const recital = await obtenerRecitalPorId(id);
    if (!recital) {
      return res.status(404).json({ error: "Recital no encontrado" });
    }

    res.json(recital);
  } catch (error) {
    res.status(500).json({ error: "Error al buscar el recital", detalle: error.message });
  }
}

/**
 * POST /api/recitales  o  POST /api/proyectos
 * Crea un recital/proyecto. Requiere mínimo 5 datos (uno link y otro imagen).
 */
export async function crear(req, res) {
  try {
    const faltantes = validarCamposObligatorios(req.body, [
      ["nombre", "name"],
      ["descripcion", "description"],
      ["link", "url"],
      ["imagen", "img", "foto"],
      ["seccion", "section"],
    ]);

    if (faltantes.length > 0) {
      return res.status(400).json({
        error: `Faltan campos obligatorios: ${faltantes.join(", ")}`,
      });
    }

    const seccion = req.body.seccion || req.body.section;
    if (!existeSeccion(seccion)) {
      return res.status(400).json({
        error: `La sección '${seccion}' no es válida. Secciones disponibles: rock, pop, electronica, indie, metal`,
      });
    }

    const clienteId = req.body.clienteId || req.body.clientId;
    if (clienteId) {
      if (!ObjectId.isValid(clienteId)) {
        return res.status(400).json({ error: "clienteId no tiene un formato válido" });
      }
      const cliente = await obtenerClientePorId(clienteId);
      if (!cliente) {
        return res.status(404).json({ error: "El cliente especificado no existe" });
      }
    }

    const bandaId = req.body.bandaId || req.body.bandId;
    if (bandaId) {
      if (!ObjectId.isValid(bandaId)) {
        return res.status(400).json({ error: "bandaId no tiene un formato válido" });
      }
    }

    const recital = await crearRecital(req.body);
    res.status(201).json(recital);
  } catch (error) {
    res.status(500).json({ error: "Error al crear el recital", detalle: error.message });
  }
}

/**
 * PUT /api/recitales/:id  o  PUT /api/proyectos/:id
 */
export async function actualizar(req, res) {
  try {
    const { id } = req.params;
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: "El ID proporcionado no es válido" });
    }

    const seccion = req.body.seccion || req.body.section;
    if (seccion && !existeSeccion(seccion)) {
      return res.status(400).json({
        error: `La sección '${seccion}' no es válida.`,
      });
    }

    const clienteId = req.body.clienteId || req.body.clientId;
    if (clienteId) {
      if (!ObjectId.isValid(clienteId)) {
        return res.status(400).json({ error: "clienteId no tiene un formato válido" });
      }
      const cliente = await obtenerClientePorId(clienteId);
      if (!cliente) {
        return res.status(404).json({ error: "El cliente especificado no existe" });
      }
    }

    const recital = await actualizarRecital(id, req.body);
    if (!recital) {
      return res.status(404).json({ error: "Recital no encontrado" });
    }

    res.json(recital);
  } catch (error) {
    res.status(500).json({ error: "Error al actualizar el recital", detalle: error.message });
  }
}

/**
 * DELETE /api/recitales/:id  o  DELETE /api/proyectos/:id
 */
export async function eliminar(req, res) {
  try {
    const { id } = req.params;
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: "El ID proporcionado no es válido" });
    }

    const eliminado = await eliminarRecital(id);
    if (!eliminado) {
      return res.status(404).json({ error: "Recital no encontrado" });
    }

    res.status(200).json({ message: "Recital eliminado exitosamente", id });
  } catch (error) {
    res.status(500).json({ error: "Error al eliminar el recital", detalle: error.message });
  }
}

// ==========================================
// CLIENTES (Parte 3)
// ==========================================

/**
 * GET /api/clientes
 * Obtener todos los clientes.
 */
export async function listarClientes(req, res) {
  try {
    const clientes = await obtenerClientes();
    res.json(clientes);
  } catch (error) {
    res.status(500).json({ error: "Error al listar clientes", detalle: error.message });
  }
}

/**
 * GET /api/clientes/:id
 */
export async function obtenerClienteHandler(req, res) {
  try {
    const { id } = req.params;
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: "ID de cliente no válido" });
    }

    const cliente = await obtenerClientePorId(id);
    if (!cliente) {
      return res.status(404).json({ error: "Cliente no encontrado" });
    }

    res.json(cliente);
  } catch (error) {
    res.status(500).json({ error: "Error al obtener cliente", detalle: error.message });
  }
}

/**
 * POST /api/clientes
 * Crear un cliente (Nombre, Foto, Descripción).
 */
export async function crearClienteHandler(req, res) {
  try {
    const faltantes = validarCamposObligatorios(req.body, [
      ["nombre", "name"],
      ["foto", "photo", "img"],
      ["descripcion", "description"],
    ]);

    if (faltantes.length > 0) {
      return res.status(400).json({
        error: `Faltan campos obligatorios para el cliente: ${faltantes.join(", ")}`,
      });
    }

    const cliente = await crearCliente(req.body);
    res.status(201).json(cliente);
  } catch (error) {
    res.status(500).json({ error: "Error al crear cliente", detalle: error.message });
  }
}

/**
 * PUT /api/clientes/:id
 */
export async function actualizarClienteHandler(req, res) {
  try {
    const { id } = req.params;
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: "ID de cliente no válido" });
    }

    const cliente = await actualizarCliente(id, req.body);
    if (!cliente) {
      return res.status(404).json({ error: "Cliente no encontrado" });
    }

    res.json(cliente);
  } catch (error) {
    res.status(500).json({ error: "Error al actualizar cliente", detalle: error.message });
  }
}

/**
 * DELETE /api/clientes/:id
 */
export async function eliminarClienteHandler(req, res) {
  try {
    const { id } = req.params;
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: "ID de cliente no válido" });
    }

    const eliminado = await eliminarCliente(id);
    if (!eliminado) {
      return res.status(404).json({ error: "Cliente no encontrado" });
    }

    res.status(200).json({ message: "Cliente eliminado correctamente", id });
  } catch (error) {
    res.status(500).json({ error: "Error al eliminar cliente", detalle: error.message });
  }
}

/**
 * GET /api/clientes/:id/proyectos  o  GET /api/clientes/:id/recitales
 * Trae todos los proyectos/recitales que pertenecen a un cliente particular.
 * Si el cliente existe pero no tiene proyectos, devuelve un array vacío [].
 * Si el cliente no existe, devuelve 404.
 */
export async function listarProyectosDeCliente(req, res) {
  try {
    const { id } = req.params;
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: "ID de cliente no válido" });
    }

    const cliente = await obtenerClientePorId(id);
    if (!cliente) {
      return res.status(404).json({ error: "Cliente no encontrado" });
    }

    const proyectos = await obtenerProyectosPorCliente(id);
    res.json(proyectos);
  } catch (error) {
    res.status(500).json({ error: "Error al obtener proyectos del cliente", detalle: error.message });
  }
}

/**
 * POST /api/proyectos
 * Crea un proyecto/recital asociado a un cliente.
 */
export async function crearProyectoHandler(req, res) {
  try {
    const clienteId = req.body.clienteId || req.body.clientId;
    if (!clienteId || !ObjectId.isValid(clienteId)) {
      return res.status(400).json({ error: "clienteId es obligatorio y debe ser un ObjectId válido" });
    }

    const cliente = await obtenerClientePorId(clienteId);
    if (!cliente) {
      return res.status(404).json({ error: "Cliente no encontrado" });
    }

    const faltantes = validarCamposObligatorios(req.body, [
      ["nombre", "name"],
      ["descripcion", "description"],
    ]);

    if (faltantes.length > 0) {
      return res.status(400).json({ error: `Faltan campos obligatorios: ${faltantes.join(", ")}` });
    }

    const proyecto = await crearProyecto(req.body);
    res.status(201).json(proyecto);
  } catch (error) {
    res.status(500).json({ error: "Error al crear proyecto", detalle: error.message });
  }
}

// ==========================================
// BANDAS (Colección adicional de la temática)
// ==========================================

export async function listarBandas(req, res) {
  try {
    const bandas = await obtenerBandas();
    res.json(bandas);
  } catch (error) {
    res.status(500).json({ error: "Error al listar bandas", detalle: error.message });
  }
}

export async function obtenerBandaHandler(req, res) {
  try {
    const { id } = req.params;
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: "ID de banda no válido" });
    }

    const banda = await obtenerBandaPorId(id);
    if (!banda) {
      return res.status(404).json({ error: "Banda no encontrada" });
    }

    res.json(banda);
  } catch (error) {
    res.status(500).json({ error: "Error al obtener la banda", detalle: error.message });
  }
}

export async function crearBandaHandler(req, res) {
  try {
    const faltantes = validarCamposObligatorios(req.body, [
      ["nombre", "name"],
      ["foto", "photo", "img"],
      ["descripcion", "description"],
    ]);

    if (faltantes.length > 0) {
      return res.status(400).json({ error: `Faltan campos obligatorios: ${faltantes.join(", ")}` });
    }

    const banda = await crearBanda(req.body);
    res.status(201).json(banda);
  } catch (error) {
    res.status(500).json({ error: "Error al crear banda", detalle: error.message });
  }
}

export async function recitalesDeBanda(req, res) {
  try {
    const { id } = req.params;
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: "ID de banda no válido" });
    }

    const banda = await obtenerBandaPorId(id);
    if (!banda) {
      return res.status(404).json({ error: "Banda no encontrada" });
    }

    const recitales = await obtenerRecitalesPorBanda(id);
    res.json(recitales);
  } catch (error) {
    res.status(500).json({ error: "Error al obtener recitales de la banda", detalle: error.message });
  }
}
