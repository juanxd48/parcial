import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import "dotenv/config";
import { connectDB } from "./config/db.js";
import webRoutes from "./routes/webRoutes.js";
import apiRoutes from "./routes/apiRoutes.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3333;

const app = express();

// Motor de vistas para las páginas dinámicas
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "..", "views"));

// Archivos estáticos (css, etc.)
app.use(express.static(path.join(__dirname, "..", "public")));

// Body parsers (para cuando lleguen los forms del ABM y la API)
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rutas
app.use("/", webRoutes);
app.use("/api", apiRoutes);

async function iniciar() {
  await connectDB();
  app.listen(PORT, () => {
    console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
  });
}

iniciar();
