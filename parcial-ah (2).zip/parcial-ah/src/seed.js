// Script para cargar datos de prueba completos para el parcial.
// Ejecutar con: node src/seed.js
import { connectDB, closeDB } from "./config/db.js";

const clientesEjemplo = [
  {
    nombre: "DF Entertainment",
    foto: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=500&auto=format&fit=crop&q=80",
    descripcion: "Productora líder de espectáculos masivos, megafestivales y estadios en Argentina.",
  },
  {
    nombre: "PopArt Music",
    foto: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=500&auto=format&fit=crop&q=80",
    descripcion: "Desarrollo artístico y producción integral de festivales de rock, pop e indie nacional.",
  },
  {
    nombre: "Movistar Arena Producciones",
    foto: "https://images.unsplash.com/photo-1540039155733-5bb30b53aa14?w=500&auto=format&fit=crop&q=80",
    descripcion: "Centro de entretenimiento y espectáculos de nivel internacional ubicado en Villa Crespo.",
  },
  {
    nombre: "Niceto Live Sessions",
    foto: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&auto=format&fit=crop&q=80",
    descripcion: "Espacio de referencia de la música en vivo, vanguardia electrónica e indie porteño.",
  },
  {
    nombre: "Underground Producciones BA",
    foto: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=500&auto=format&fit=crop&q=80",
    descripcion: "Productora boutique emergente. Actualmente en etapa de pre-producción de su primera temporada (0 proyectos activos).",
  },
];

const bandasEjemplo = [
  {
    nombre: "Bandalos Chinos",
    foto: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&auto=format&fit=crop&q=80",
    descripcion: "Sexteto de indie pop nacido en Beccar, referente de la nueva canción latinoamericana.",
  },
  {
    nombre: "AC/DC",
    foto: "https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?w=500&auto=format&fit=crop&q=80",
    descripcion: "Leyendas del hard rock mundial con guitarras eléctricas electrizantes y potencia inigualable.",
  },
  {
    nombre: "Babasónicos",
    foto: "https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=500&auto=format&fit=crop&q=80",
    descripcion: "Banda icónica del rock alternativo y pop sofisticado argentino con más de 30 años de trayectoria.",
  },
  {
    nombre: "Hernán Cattaneo",
    foto: "https://images.unsplash.com/photo-1571266028243-3716f02d2d2e?w=500&auto=format&fit=crop&q=80",
    descripcion: "DJ y productor embajador del progressive house argentino con presentaciones globales.",
  },
  {
    nombre: "Slayer",
    foto: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=500&auto=format&fit=crop&q=80",
    descripcion: "Pioneros del thrash metal con velocidad extrema, potencia y riffs demoledores.",
  },
];

async function seed() {
  const db = await connectDB();

  console.log("Limpiando colecciones anteriores...");
  await db.collection("recitales").deleteMany({});
  await db.collection("proyectos").deleteMany({});
  await db.collection("clientes").deleteMany({});
  await db.collection("bandas").deleteMany({});

  console.log("Insertando clientes...");
  const clientesInsertados = await db.collection("clientes").insertMany(clientesEjemplo);
  const clienteIds = Object.values(clientesInsertados.insertedIds);
  const [idDF, idPopArt, idMovistar, idNiceto, idUnderground] = clienteIds;

  console.log("Insertando bandas...");
  const bandasInsertadas = await db.collection("bandas").insertMany(bandasEjemplo);
  const bandaIds = Object.values(bandasInsertadas.insertedIds);
  const [idBandalos, idACDC, idBabasonicos, idCattaneo, idSlayer] = bandaIds;

  console.log("Insertando recitales / proyectos...");
  const recitalesEjemplo = [
    {
      nombre: "Bandalos Chinos - Gira 'El Big Blue'",
      descripcion: "Noche consagratoria al aire libre presentando sus mayores éxitos de pop e indie.",
      link: "https://movistararena.com.ar/bandalos-chinos",
      imagen: "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=800&auto=format&fit=crop&q=80",
      fecha: "2026-11-14",
      lugar: "Movistar Arena (Villa Crespo)",
      artistas: ["Bandalos Chinos", "El Kuelgue", "Usted Señalemelo"],
      seccion: "indie",
      clienteId: idPopArt,
      bandaId: idBandalos,
      creadoEn: new Date(),
    },
    {
      nombre: "AC/DC - PWR UP Tour 2026",
      descripcion: "El regreso más esperado de las leyendas del rock en el estadio más grande del país.",
      link: "https://allaccess.com.ar/acdc-river",
      imagen: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&auto=format&fit=crop&q=80",
      fecha: "2026-10-02",
      lugar: "Estadio Mâs Monumental (River Plate)",
      artistas: ["AC/DC", "Airbag"],
      seccion: "rock",
      clienteId: idDF,
      bandaId: idACDC,
      creadoEn: new Date(),
    },
    {
      nombre: "Babasónicos en Concierto Sinfónico",
      descripcion: "Una puesta teatral y psicodélica con arreglos de cuerdas y synth-pop deslumbrante.",
      link: "https://movistararena.com.ar/babasonicos",
      imagen: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=800&auto=format&fit=crop&q=80",
      fecha: "2026-10-25",
      lugar: "Movistar Arena (Villa Crespo)",
      artistas: ["Babasónicos"],
      seccion: "pop",
      clienteId: idMovistar,
      bandaId: idBabasonicos,
      creadoEn: new Date(),
    },
    {
      nombre: "Hernán Cattaneo Sunsetstrip 2026",
      descripcion: "El viaje musical definitivo desde el atardecer hasta la noche con sonido envolvente.",
      link: "https://sunsetstrip.com.ar",
      imagen: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800&auto=format&fit=crop&q=80",
      fecha: "2026-12-05",
      lugar: "Campo Argentino de Polo (Palermo)",
      artistas: ["Hernán Cattaneo", "Nick Warren", "Graziano Raffa"],
      seccion: "electronica",
      clienteId: idDF,
      bandaId: idCattaneo,
      creadoEn: new Date(),
    },
    {
      nombre: "Slayer - Final Carnage Tour",
      descripcion: "El recital más demoledor del metal internacional con una muralla de amplificadores.",
      link: "https://groove.com.ar/slayer",
      imagen: "https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=800&auto=format&fit=crop&q=80",
      fecha: "2026-11-20",
      lugar: "Teatro Flores (Flores)",
      artistas: ["Slayer", "Malón"],
      seccion: "metal",
      clienteId: idPopArt,
      bandaId: idSlayer,
      creadoEn: new Date(),
    },
    {
      nombre: "Furia Metal Fest: Tributo a las Sombras",
      descripcion: "Festival de bandas pesadas con escenografía de fuego, distorsión y doble bombo.",
      link: "https://entradas.com/furia-metal",
      imagen: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=800&auto=format&fit=crop&q=80",
      fecha: "2026-12-12",
      lugar: "Teatro Vorterix (Colegiales)",
      artistas: ["A.N.I.M.A.L.", "Plan 4", "Against"],
      seccion: "metal",
      clienteId: idNiceto,
      bandaId: null,
      creadoEn: new Date(),
    },
    {
      nombre: "Club Niceto Electrónica All Night",
      descripcion: "Sesión continua de techno hipnótico y visuales interactivas en vivo.",
      link: "https://nicetoclub.com/agenda/club-electronica",
      imagen: "https://images.unsplash.com/photo-1571266028243-3716f02d2d2e?w=800&auto=format&fit=crop&q=80",
      fecha: "2026-10-18",
      lugar: "Niceto Club (Palermo)",
      artistas: ["Mariano Mellino", "Kevin Di Serna"],
      seccion: "electronica",
      clienteId: idNiceto,
      bandaId: null,
      creadoEn: new Date(),
    },
    {
      nombre: "Festival Primavera Pop Latino",
      descripcion: "Las melodías y coreografías más pegadizas del nuevo pop urbano y cancionero.",
      link: "https://movistararena.com.ar/primavera-pop",
      imagen: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&auto=format&fit=crop&q=80",
      fecha: "2026-11-28",
      lugar: "Movistar Arena (Villa Crespo)",
      artistas: ["Conociendo Rusia", "Miranda!", "Zoe Gotusso"],
      seccion: "pop",
      clienteId: idMovistar,
      bandaId: null,
      creadoEn: new Date(),
    },
  ];

  const recitalesInsertados = await db.collection("recitales").insertMany(recitalesEjemplo);

  // Sincronizar en colección proyectos para compatibilidad
  const proyectosLegacy = recitalesEjemplo.map((r, i) => ({
    _id: recitalesInsertados.insertedIds[i],
    nombre: r.nombre,
    descripcion: r.descripcion,
    clienteId: r.clienteId,
    creadoEn: new Date(),
  }));
  await db.collection("proyectos").insertMany(proyectosLegacy);

  console.log("✅ Seed completado con éxito:");
  console.log(`   - ${clientesEjemplo.length} Clientes (incluyendo 1 cliente sin proyectos para testeo de la consigna)`);
  console.log(`   - ${bandasEjemplo.length} Bandas`);
  console.log(`   - ${recitalesEjemplo.length} Recitales/Proyectos repartidos en las 5 secciones`);

  await closeDB();
}

seed().catch((err) => {
  console.error("Error al ejecutar seed:", err);
  process.exit(1);
});
